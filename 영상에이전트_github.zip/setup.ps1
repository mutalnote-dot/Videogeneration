﻿# 로컬 맛집 숏폼 에이전트 설치 스크립트 (새 PC에서 한 번만 실행)
#   powershell -ExecutionPolicy Bypass -File .\setup.ps1              ← 기본
#   powershell -ExecutionPolicy Bypass -File .\setup.ps1 -WithWhisper ← 음성인식(선택, 약 1GB 추가)까지
# - ffmpeg     : tools\ffmpeg 에 설치 (시스템 PATH 변경 없음) — FFmpeg 국제 오픈소스, gyan.dev 빌드
# - Python 3.12: tools\python 에 압축본 설치 (시스템 변경 없음) — Python 재단(미국)
# - 글꼴       : tools\fonts 에 프리텐다드 (OFL 무료, 한국)
# - 라이브러리 : OpenCV(얼굴 흐림), Pillow(커버), numpy, pypdf·pypdfium2(PDF 가이드 읽기)
param([switch]$WithWhisper)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
foreach ($d in 'input','reference','music','output','work','plans') { New-Item -ItemType Directory -Force (Join-Path $root $d) | Out-Null }

# 1) ffmpeg (gyan.dev essentials, 약 100MB)
$ffDir = Join-Path $root 'tools\ffmpeg'
if (-not (Test-Path (Join-Path $ffDir 'bin\ffmpeg.exe'))) {
    Write-Host '[1/3] ffmpeg 다운로드 중 (약 100MB)...'
    $zip = Join-Path $env:TEMP 'ffmpeg-essentials.zip'
    $urls = @('https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip',
              'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip')
    $done = $false
    foreach ($u in $urls) {
        try { Invoke-WebRequest $u -OutFile $zip -UseBasicParsing; $done = $true; break }
        catch { Write-Host "  실패: $u ($($_.Exception.Message)) → 다른 주소로 재시도" }
    }
    if (-not $done) { throw 'ffmpeg 다운로드 실패' }
    $tmp = Join-Path $env:TEMP 'ffmpeg-extract'
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
    Expand-Archive $zip $tmp
    $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
    New-Item -ItemType Directory -Force $ffDir | Out-Null
    Copy-Item -Recurse -Force (Join-Path $inner.FullName 'bin') $ffDir
    Remove-Item -Recurse -Force $tmp, $zip
} else { Write-Host '[1/3] ffmpeg 이미 설치됨' }

# 2) Python
function Find-Python {
    $local = Join-Path $root 'tools\python\python.exe'
    if (Test-Path $local) { return $local }
    foreach ($c in @('py','python')) { $p = Get-Command $c -ErrorAction SilentlyContinue; if ($p -and $p.Source -notlike '*WindowsApps*') { return $p.Source } }
    $cand = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
    if (Test-Path $cand) { return $cand }
    return $null
}
$py = Find-Python
if (-not $py) {
    # 설치 프로그램 없이 python.org 공식 NuGet 패키지(압축본)를 tools\python 에 풀어서 사용
    Write-Host '[2/3] Python 3.12 다운로드 중 (약 15MB)...'
    $pkg = Join-Path $env:TEMP 'python-3.12.10.zip'
    Invoke-WebRequest 'https://www.nuget.org/api/v2/package/python/3.12.10' -OutFile $pkg -UseBasicParsing
    $tmp = Join-Path $env:TEMP 'python-extract'
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
    Expand-Archive $pkg $tmp
    Copy-Item -Recurse -Force (Join-Path $tmp 'tools') (Join-Path $root 'tools\python')
    Remove-Item -Recurse -Force $tmp, $pkg
    $py = Join-Path $root 'tools\python\python.exe'
    & $py -m ensurepip --upgrade
} else { Write-Host "[2/3] Python 이미 설치됨: $py" }

# 2-1) 프리텐다드 글꼴 (OFL 무료 글꼴, tools\fonts 에 저장)
$fontDir = Join-Path $root 'tools\fonts'
New-Item -ItemType Directory -Force $fontDir | Out-Null
foreach ($w in 'Bold','ExtraBold') {
    $f = Join-Path $fontDir "Pretendard-$w.otf"
    if (-not (Test-Path $f)) { Invoke-WebRequest "https://cdn.jsdelivr.net/npm/pretendard@1.3.9/dist/public/static/Pretendard-$w.otf" -OutFile $f -UseBasicParsing }
}

# 3) 파이썬 라이브러리
#    OpenCV 5.x 는 얼굴 검출 모델(Haar)이 빠져 있어서 4.x 로 고정
Write-Host '[3/3] 파이썬 라이브러리 설치 중...'
& $py -m pip install --upgrade pip --quiet --no-warn-script-location
& $py -m pip install "opencv-python-headless<5" pillow numpy pypdf pypdfium2 --quiet --no-warn-script-location
if ($WithWhisper) {
    Write-Host '  + 음성인식(faster-whisper, SYSTRAN·프랑스) 설치 중...'
    & $py -m pip install faster-whisper --quiet --no-warn-script-location
}

& $py (Join-Path $root 'tools\shorts.py') check
