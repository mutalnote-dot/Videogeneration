# 로컬 맛집 숏폼 제작 에이전트

하남·미사 로컬 크리에이터가 **매장 방문 영상 폴더 + 후기 한 줄**만 주면,
인스타그램 릴스·네이버 클립용 **나레이션 숏폼(21~30초) · 콜라주 커버 · 5단계 캡션**까지 만들어 주는 Claude Code 에이전트.

```
"영상 만들어줘. [가림1]" + 후기
        │
        ▼
 분석 → 구성안(확인 1회) → 렌더(음소거·자막·얼굴흐림) → 검수 → 커버 → 캡션 → 캡컷 넘기기(SRT) → (요청 시) 캡컷 '애덤' → 보고
```

- 상세 작업 지침: `.claude/skills/viral-shorts/SKILL.md` (이 프로젝트의 핵심 스킬, "영상 만들어줘"로 실행)
- 캡컷 나레이션 조작 절차: `.claude/skills/viral-shorts/capcut_narration.md`
- 크리에이터 양식(최우선): `guides/creator_style.md` · 숏폼 전략 요약: `guides/rules.md`

---

## 1. 사용자와 채널

- 경기 하남·미사 로컬 리뷰어. 초3·초6 남매를 둔 3040 엄마 크리에이터. 맛집·디저트·뷰티·라이프스타일, 체험단(협찬) 후기 위주.
- 계정 톤: 상단 **검정 박스 + 흰 글씨(강조는 노랑)** 두 줄 헤드카피, 지역명(미사·망월동) 들어간 반말 카피.
- 사용자는 코딩을 하지 않는다. 설명은 쉬운 한국어, 결과 위주로.
- Claude Pro 요금제 → **토큰 절약이 중요**.

## 2. 절대 원칙 (어기지 말 것)

1. **중국에서 만든 소스 금지** — 도구·라이브러리·AI 모델·서비스 모두. 출처(개발 주체·국가)를 확인할 수 없는 것도 쓰지 않는다.
   새 부품을 추가하기 전 개발 주체를 확인하고 사용자에게 알린다.
   - 예외: 사용자가 구독 중인 **캡컷(CapCut)** 은 사용자 허락으로 사용.
   - 현재 부품 출처: FFmpeg(국제 오픈소스, gyan.dev 빌드) · Python(PSF, 미국) · faster-whisper/CTranslate2(SYSTRAN, 프랑스) ·
     OpenCV(OpenCV 재단, 미국) · Pillow·pypdf·pypdfium2(오픈소스/구글 PDFium) · 프리텐다드 글꼴(한국) · 캡컷(예외).
2. **구성안 먼저** — 렌더 전에 구성안을 보여주고 확인 1회. 확정된 **1개 버전만** 렌더(A/B/C는 요청 시에만).
   사용자가 "구성안 없이 바로"라고 하면 생략.
3. **아이 보호** — 아이 먹는 모습은 넣되 `blur_face: "upper"`(눈·이마만 흐림, 입 모양은 보이게). 렌더 후 반드시 확대 확인.
   눈이 보이는데 자동 검출이 실패한 컷은 빼거나 `blur_box`로 지정. 커버에는 얼굴 장면을 쓰지 않는다.
4. **협찬 표기** — 영상 화면에는 '협찬' 글자를 넣지 않는다. 캡션 첫 줄 `[협찬]`(또는 도입부) + `#협찬`, 인스타 '유료 광고' 표시는 사용자가 켬.
5. **음성인식 안 함** — 자막·나레이션은 사용자 후기를 바탕으로 직접 쓴다(`analyze` 기본값이 음성인식 끔).
6. **헤드카피가 핵심 피사체(음식·간판·얼굴)를 가리면** 그 구간 `hook_hide`.
7. **커버는 성의 있게** — 영상 프레임 그대로 + 자막 범벅 금지. 콜라주(위 패널 + 아래 패널 + 동그란 포인트 메뉴 + 라벨 + 헤드카피),
   프로필 그리드(3:4로 위아래 잘림)에서도 헤드카피·음식이 보이게.
8. **확실하지 않은 사실은 쓰지 않는다** — 가격은 메뉴판에서 확인한 것만, 아이 학년·메뉴 구성 등 추측은 보고에서 확인 요청.
9. 결제·구독·로그인 창이 뜨면 즉시 멈추고 사용자에게 넘긴다. 캡컷 계정·설정은 바꾸지 않는다.
10. 레퍼런스 영상은 구조·리듬만 참고. 남의 문구·음원·화면을 복사하지 않는다.

## 3. 콘텐츠 규칙 요약 (상세는 guides/creator_style.md)

- **길이** 21~30초, 컷 1.2~2.2초. **나레이션 100~130음절**, 8문장 안팎, 문장당 2.5~4초.
- **0초** = 가장 먹음직스럽거나 센스 있는 장면, 첫 나레이션은 그 화면과 일치(헤드카피와 같은 메시지).
- **헤드카피 4대 공식**: 숫자+의외성 / 타깃·상황 콕 집기 / 반전·예상 깨기 / 결과 선공개. '손해' 키워드 반복 금지. 12~18자, 2줄.
- **CTA**: [저장📌] 또는 [공유✈️]. 뻔한 댓글 유도 금지. 마지막 간판·전경 컷에 "<지역> <업종> 맛집 | [저장]해두세요" 류.
- **미션 가이드**(체험단)가 있으면 항목별로 컷에 배치: 시그니처 메뉴, 신선한 재료 클로즈업, 인테리어, 플레이팅, 식사 장면, 재방문 이유.
- **캡션 5단계**: ① 도입(0초 나레이션과 같은 문장 + 매장명·동행) ② 추천 포인트 1️⃣ 2️⃣ 3️⃣(제목 한 줄 + 설명 2~3문장)
  ③ "꺼내 보시게 지금 [저장📌] 해두시고, … [공유✈️] 해보세요!" ④ 📍 매장명 / 주소 / 추천 메뉴·가격 ⑤ 해시태그 8~10개(#협찬 + 매장명 + 지역 태그).
- 사용자가 "통글" / "모바일 복붙용"이라고 하면 줄바꿈·코드박스 없는 한 덩어리 텍스트로.
- 화면: 1080×1920, 프리텐다드 ExtraBold, 자막은 흰 글씨+검정 외곽선(강조 노랑), 안전영역(상단 230px·하단 480px·우측 230px 피하기).
- 음악은 넣지 않는다 → 사용자가 인스타 앱에서 유행 음원을 붙임.

## 4. 폴더 구조

```
영상/
├─ CLAUDE.md                ← 이 파일 (프로젝트 규칙)
├─ README.md                ← 사용자용 설명
├─ setup.ps1                ← 새 PC 설치 (ffmpeg·Python·글꼴·라이브러리)
├─ .claude/skills/viral-shorts/
│   ├─ SKILL.md             ← 전체 작업 흐름·plan 형식
│   └─ capcut_narration.md  ← 캡컷 애덤 나레이션 조작 절차(첫 실행 후 '확인된 화면 메모' 갱신)
├─ guides/                  ← creator_style.md(양식), rules.md(전략 요약), 원본 PDF(유료 자료 — 외부 공유 금지)
├─ tools/
│   ├─ shorts.py            ← 편집 엔진 (analyze / overview / sheet / render / check)
│   ├─ fonts/               ← Pretendard Bold·ExtraBold (OFL)
│   ├─ python/              ← 프로젝트 전용 Python (setup.ps1이 설치, 옮기지 않음)
│   └─ ffmpeg/              ← FFmpeg (setup.ps1이 설치, 옮기지 않음)
├─ input/<매장>/            ← 원본 영상 (개인 영상 — 외부 공유 금지)
├─ plans/<매장>/<제목>.json ← 편집 계획서 (컷·자막·나레이션·커버·캡션)
├─ output/<매장>/           ← 완성본, _cover.jpg, _caption.txt, _narration.srt, 캡컷용/
├─ work/                    ← 임시(시트 이미지·렌더 중간파일) — 지워도 됨
├─ reference/ · music/      ← 선택(레퍼런스 영상, 저작권 문제없는 음원)
```

## 5. 도구 명령 (프로젝트 루트에서)

`python` = `.\tools\python\python.exe` (PATH에 없음)

| 명령 | 하는 일 |
|---|---|
| `python tools/shorts.py check` | 설치 점검 |
| `python tools/shorts.py analyze <매장>` | 길이·컷 분석, 시트 이미지 (`--whisper`로 음성인식, 기본 끔) |
| `python tools/shorts.py overview <매장> --n 5 --rows 10` | 영상 수십 개를 몇 장 요약 이미지로 (토큰 절약용, 먼저 이것만 본다) |
| `python tools/shorts.py sheet <파일> --start 1 --end 4 --n 6` | 특정 구간 확대 확인 |
| `python tools/shorts.py render plans/<매장>/<제목>.json` | 렌더 → 완성본·커버·캡션·SRT·캡컷용 폴더 |
| `python tools/review.py plans/<매장>/<제목>.json` | 자동 채점표 + 확인 이미지 3장(`work/review/<제목>/`) — 검수 에이전트 `shorts-reviewer`가 사용 |

plan 주요 키(상세는 SKILL.md): `project`, `mute`, `narration`, `hook_text`/`hook_box`/`hook_hide`, `cta_text`,
`clips[]`(`start`·`end`·`speed`·`zoom`·`blur_face`), `cover_layout`(top·bottom·circle), `caption`, `hashtags`.
**캡션은 plan의 `caption`/`hashtags`에 넣는다** — 렌더할 때마다 `_caption.txt`가 plan 기준으로 다시 써지기 때문.

알려진 주의점:
- OpenCV는 한글 경로 파일을 못 연다 → 얼굴 검출 모델을 임시 폴더(영문 경로)로 복사해 쓴다(코드에 반영됨).
- PDF 가이드는 글자 없는 긴 이미지일 수 있다 → pypdfium2로 이미지로 바꿔 나눠 읽고, 규칙만 `guides/rules.md`에 요약(매번 다시 읽지 않기).
- 캡컷 편집 창은 `capcut.exe` 프로세스 → 컴퓨터 사용 권한을 "CapCut"과 "capcut.exe" 둘 다 요청.

## 6. 다른 PC로 옮기기

1. 옮길 것: `CLAUDE.md`, `README.md`, `setup.ps1`, `.claude/`, `guides/*.md`, `tools/shorts.py`, `tools/fonts/`, `plans/`.
   옮기지 않을 것: `tools/python`, `tools/ffmpeg`(재설치), `input/`, `output/`, `work/`, 유료 PDF.
2. 새 PC에서 Claude Code 설치 → 폴더 열기 → `powershell -ExecutionPolicy Bypass -File .\setup.ps1`.
3. "영상 만들어줘. <매장 폴더>" + 후기.
4. 캡컷 나레이션 단계를 쓰려면 Claude 앱 **설정 → 기능 → 컴퓨터 사용** 켜기, 캡컷 PC 설치·로그인.

## 7. 현재 상태 · 남은 일 (2026-11-25 기준)

- 완료: 붕어빵(금당리), [가림1] 숏폼. [가림1]은 나레이션 버전(음소거 + 자막 + SRT + 콜라주 커버 + 5단계 캡션)까지.
- 2026-11-25: 사용자가 AI 말투 대신 **캡컷에서 직접 말투를 고치기로** 함 → 기본 흐름은 'SKILL 8단계 캡컷 넘기기(나레이션 SRT 전달)'에서 끝.
  캡컷 '애덤' 자동 나레이션(9단계)은 요청 시에만. 아직 실제 실행 전 — 첫 실행 후 `capcut_narration.md` 갱신.
- 이식 준비 완료(2026-11-24): `setup.ps1`이 OpenCV(<5)·Pillow·numpy·pypdf·pypdfium2까지 설치(음성인식은 `-WithWhisper` 선택),
  고정 경로 제거(`tools/*.py`는 `Path(__file__)` 기준, 캡컷 절차서는 `Resolve-Path`로 실제 경로 구함), `.gitignore`로 개인 영상·유료 PDF·재설치 대상 제외.
- 완료(2026-11-25): 독립 검수 에이전트 `.claude/agents/shorts-reviewer.md` + `tools/review.py`(SKILL 6단계에 연결).
  첫 시험에서 [가림1] 캡션 첫 줄 [협찬] 누락을 잡음.
- 과제 제출용 남은 후보: 단축 명령, 구조도·시연 자료.
- 다른 세션에서 만든 파일: `plans/[가림2]*`, `tools/dubbing.py`, `tools/make_cover.py`, 루트 `test_*.mp3`.
  ⚠️ `tools/dubbing.py`는 **edge-tts**(개발자 국적 미확인 → 원칙 2-1 위반 소지)를 쓴다. 기본 흐름에서는 쓰지 않으며, 사용 여부는 사용자 확인 필요.
