import os
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent.parent  # 프로젝트 폴더 (PC마다 위치가 달라도 동작)
FONT_BOLD = str(ROOT / "tools" / "fonts" / "Pretendard-Bold.otf")
FONT_EBOLD = str(ROOT / "tools" / "fonts" / "Pretendard-ExtraBold.otf")
FFMPEG = str(ROOT / "tools" / "ffmpeg" / "bin" / "ffmpeg.exe")

W, H = 1080, 1920

def create_gradient_mask(w, h, start_y=900, max_alpha=200):
    gradient = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(gradient)
    for y in range(start_y, h):
        progress = (y - start_y) / (h - start_y)
        # Smooth quadratic curve for natural vignette
        alpha = int((progress ** 1.3) * max_alpha)
        draw.line([(0, y), (w, y)], fill=(0, 0, 0, alpha))
    return gradient

def add_thumbnail_text(base_img, lines, font_size=60, x=75, bottom_y=1420):
    img = base_img.convert("RGBA")
    grad = create_gradient_mask(W, H, start_y=950, max_alpha=210)
    img = Image.alpha_composite(img, grad)

    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_EBOLD, font_size)

    line_height = int(font_size * 1.32)
    total_text_h = len(lines) * line_height
    start_y = bottom_y - total_text_h

    for i, line in enumerate(lines):
        y = start_y + i * line_height
        # Draw soft shadow
        for dx, dy, s_alpha in [(-2, 2, 80), (2, 2, 120), (0, 3, 100)]:
            draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0, s_alpha))
        # Draw main text in pure white
        draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))

    return img.convert("RGB")

def extract_frame(video_path, time_sec):
    out_path = ROOT / "work" / f"frame_{Path(video_path).stem}_{time_sec}.jpg"
    cmd = [
        FFMPEG, "-y",
        "-ss", str(time_sec),
        "-i", str(video_path),
        "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
        "-frames:v", "1",
        "-q:v", "2",
        str(out_path)
    ]
    subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return Image.open(out_path)

def make_covers():
    # Candidate 1: Frame from 20261115_182917.mp4 (Spicy Marashanguo close-up)
    frame1 = extract_frame(ROOT / "input" / "[가림2]" / "20261115_182917.mp4", 0.8)
    
    # Candidate 2: Frame from 20261115_182733.mp4 (Boiling Maratang bowl)
    frame2 = extract_frame(ROOT / "input" / "[가림2]" / "20261115_182733.mp4", 2.5)

    # Candidate 3: Frame from 20261115_181604.mp4 (Bowl picking ingredients)
    frame3 = extract_frame(ROOT / "input" / "[가림2]" / "20261115_181604.mp4", 1.8)

    copy_texts = [
        ["일요일 저녁마다", "학생들 꽉 찬다는 마라탕집"],
        ["고시생 노량진처럼", "학생들 몰린다는 미사 맛집"],
        ["학생들 바글바글한 이유,", "미사 마라탕 맛집"]
    ]

    out_dir = ROOT / "output" / "[가림2]" / "썸네일후보"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Generate candidate variations
    c1 = add_thumbnail_text(frame1, copy_texts[0])
    c1.save(out_dir / "썸네일_1_샹궈_일요일저녁.jpg", quality=95)

    c2 = add_thumbnail_text(frame2, copy_texts[0])
    c2.save(out_dir / "썸네일_2_마라탕_일요일저녁.jpg", quality=95)

    c3 = add_thumbnail_text(frame1, copy_texts[2])
    c3.save(out_dir / "썸네일_3_샹궈_바글바글.jpg", quality=95)

    # Also save square crops (1:1) to verify how it looks on Instagram grid
    for name, img in [("1", c1), ("2", c2), ("3", c3)]:
        # Square crop from Y=420 to Y=1500
        sq = img.crop((0, 420, 1080, 1500))
        sq.save(out_dir / f"인스타그리드_1대1_{name}.jpg", quality=95)

    # Set candidate 1 as main cover
    c1.save(ROOT / "output" / "[가림2]" / "[가림2]_cover.jpg", quality=95)
    c1.save(ROOT / "output" / "[가림2]" / "[가림2]_더빙완성_cover.jpg", quality=95)
    print("Done generating covers!")

if __name__ == "__main__":
    make_covers()
