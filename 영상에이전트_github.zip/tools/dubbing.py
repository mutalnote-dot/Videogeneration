import asyncio
import json
import os
import subprocess
from pathlib import Path
import edge_tts

ROOT = Path(__file__).resolve().parent.parent  # 프로젝트 폴더 (PC마다 위치가 달라도 동작)
FFMPEG = str(ROOT / "tools" / "ffmpeg" / "bin" / "ffmpeg.exe")
FFPROBE = str(ROOT / "tools" / "ffmpeg" / "bin" / "ffprobe.exe")
TEMP_DIR = ROOT / "work" / "tts_temp"
TEMP_DIR.mkdir(parents=True, exist_ok=True)

NARRATIONS = [
    {"id": 1, "target_start": 0.2, "text": "학생들 바글바글한 이유가 있었네..."},
    {"id": 2, "target_start": 2.5, "text": "일요일 저녁 웨이팅에 홀린 듯 들어간 [가림2]!"},
    {"id": 3, "target_start": 5.4, "text": "원하는 재료 직접 담고 맵기 조절 완료"},
    {"id": 4, "target_start": 8.0, "text": "초딩 둘은 삼삼한 마라탕 폭풍흡입!"},
    {"id": 5, "target_start": 10.8, "text": "어른 둘은 매운맛 샹궈에 불닭 맵기 기절!"},
    {"id": 6, "target_start": 13.8, "text": "살려준 건 바로 무료 공깃밥 무한리필!"},
    {"id": 7, "target_start": 16.8, "text": "음료 무한에 나갈 땐 아이스크림까지!"},
    {"id": 8, "target_start": 19.8, "text": "가족 외식 찾으실 때 지금 저장 필수!"}
]

def get_duration(fpath):
    cmd = [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(fpath)]
    out = subprocess.check_output(cmd, text=True).strip()
    return float(out)

async def generate_audios():
    clips = []
    for item in NARRATIONS:
        out_mp3 = TEMP_DIR / f"line_{item['id']}.mp3"
        comm = edge_tts.Communicate(item["text"], "ko-KR-InJoonNeural", rate="+22%")
        await comm.save(str(out_mp3))
        dur = get_duration(out_mp3)
        clips.append({
            "id": item["id"],
            "path": out_mp3,
            "target_start": item["target_start"],
            "text": item["text"],
            "duration": dur
        })
        print(f"[{item['id']}] {dur:.2f}s: {item['text']}")
    return clips

def assemble_dubbed_video(clips):
    video_src = ROOT / "output" / "[가림2]" / "[가림2]_나레이션.mp4"
    orig_src = ROOT / "output" / "[가림2]" / "[가림2].mp4"
    final_out = ROOT / "output" / "[가림2]" / "[가림2]_더빙완성.mp4"

    # Build ffmpeg filter to position each clip at its target_start
    inputs = ["-i", str(video_src)]
    if orig_src.exists():
        inputs += ["-i", str(orig_src)]
        has_orig_audio = True
    else:
        has_orig_audio = False

    filter_complex = []
    audio_labels = []

    # Add each tts mp3 as an input
    for i, clip in enumerate(clips):
        inputs += ["-i", str(clip["path"])]
        idx = 2 + i if has_orig_audio else 1 + i
        delay_ms = int(round(clip["target_start"] * 1000))
        label = f"a{i}"
        filter_complex.append(f"[{idx}:a]adelay={delay_ms}|{delay_ms},volume=1.3[{label}]")
        audio_labels.append(f"[{label}]")

    # Mix all narration clips together
    merged_narr = f"{''.join(audio_labels)}amix=inputs={len(audio_labels)}:normalize=0[narration]"
    filter_complex.append(merged_narr)

    if has_orig_audio:
        # Mix background audio (lowered to 0.15) with narration
        filter_complex.append("[1:a]volume=0.15[bg]")
        filter_complex.append("[bg][narration]amix=inputs=2:duration=first:normalize=0[final_audio]")
        map_audio = "[final_audio]"
    else:
        map_audio = "[narration]"

    filter_str = ";".join(filter_complex)

    cmd = [
        FFMPEG, "-y",
        *inputs,
        "-filter_complex", filter_str,
        "-map", "0:v",
        "-map", map_audio,
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        str(final_out)
    ]

    print("Running ffmpeg...")
    subprocess.check_call(cmd)
    print("Done! Final dubbed video created at:", final_out)

if __name__ == "__main__":
    clips = asyncio.run(generate_audios())
    assemble_dubbed_video(clips)
