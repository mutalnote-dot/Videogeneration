#!/usr/bin/env python3
"""바이럴 숏츠 메이커 — 분석(analyze) / 렌더(render) / 미리보기(sheet) / 점검(check)

사용 예:
  python tools/shorts.py check
  python tools/shorts.py analyze                 # input/ 와 reference/ 영상 분석
  python tools/shorts.py render plans/a.json     # 편집 계획대로 9:16 숏츠 렌더링
  python tools/shorts.py sheet output/a.mp4 --n 12
"""
import argparse
import hashlib
import json
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INPUT, REF, MUSIC, OUT, WORK = (ROOT / n for n in ("input", "reference", "music", "output", "work"))
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm", ".mts"}
W, H, FPS = 1080, 1920, 30
SHEET_FONT = "C\\:/Windows/Fonts/arial.ttf"
YELLOW = "&H00FFFF&"  # ASS BGR
WHITE = "&HFFFFFF&"

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

FFMPEG = FFPROBE = None


# ───────────────────────── 공통 ─────────────────────────
def find_bin(name):
    local = ROOT / "tools" / "ffmpeg" / "bin" / f"{name}.exe"
    if local.exists():
        return str(local)
    p = shutil.which(name)
    if p:
        return p
    sys.exit(f"[오류] {name} 을(를) 찾을 수 없습니다. setup.ps1 을 먼저 실행하세요.")


def init_bins():
    global FFMPEG, FFPROBE
    FFMPEG, FFPROBE = find_bin("ffmpeg"), find_bin("ffprobe")


def run(cmd, cwd=None):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", cwd=cwd)
    if r.returncode != 0:
        sys.stderr.write(r.stderr[-4000:] + "\n")
        sys.exit(f"[오류] 명령 실패: {Path(str(cmd[0])).name} {' '.join(str(c) for c in cmd[1:6])} ...")
    return r


def probe(p):
    j = json.loads(run([FFPROBE, "-v", "error", "-print_format", "json",
                        "-show_format", "-show_streams", p]).stdout)
    v = next((s for s in j["streams"] if s.get("codec_type") == "video"), None)
    if not v:
        return None
    w, h = int(v["width"]), int(v["height"])
    rot = 0
    try:
        rot = int(float(v.get("tags", {}).get("rotate", 0)))
    except ValueError:
        pass
    for sd in v.get("side_data_list") or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    if abs(rot) % 180 == 90:
        w, h = h, w
    dur = float(j["format"].get("duration") or v.get("duration") or 0)
    return {"duration": round(dur, 2), "width": w, "height": h,
            "has_audio": any(s.get("codec_type") == "audio" for s in j["streams"])}


def fid(f):
    f = Path(f).resolve()
    st = f.stat()
    return hashlib.md5(f"{f}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()[:12]


def rel(p):
    try:
        return Path(p).resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(p)


def even(x):
    return int(math.ceil(x / 2) * 2)


def safe_name(s):
    s = re.sub(r'[\\/:*?"<>|\s]+', "_", str(s)).strip("_")
    return s or "short"


def videos_in(folder):
    if not folder.exists():
        return []
    return sorted(f for f in folder.iterdir() if f.is_file() and f.suffix.lower() in VIDEO_EXT)


# ───────────────────────── 분석 ─────────────────────────
def detect_cuts(p, thr):
    r = subprocess.run([FFMPEG, "-hide_banner", "-nostats", "-i", str(p), "-an", "-vf",
                        f"scale=320:-2,select='gt(scene,{thr})',showinfo", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return [round(float(t), 2) for t in re.findall(r"pts_time:([\d.]+)", r.stderr)]


def make_sheet(src, out, start, dur, n, cols=6):
    """구간을 n장 썸네일로 쪼개 한 장짜리 콘택트 시트(jpg)로 저장. 각 칸에 원본 기준 시간 표시."""
    n = max(1, n)
    rows = math.ceil(n / cols) if n > cols else 1
    cols = min(cols, n)
    step = max(dur / n, 0.04)
    vf = (f"fps=1/{step:.4f},scale=270:-2,"
          f"drawtext=fontfile='{SHEET_FONT}':text='%{{pts\\:hms\\:{start:.3f}}}':"
          f"x=6:y=6:fontsize=22:fontcolor=yellow:box=1:boxcolor=black@0.65,"
          f"tile={cols}x{rows}:padding=4:margin=4")
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}",
         "-i", src, "-vf", vf, "-frames:v", "1", "-q:v", "4", out])
    return out


_model = None


def get_model(name):
    global _model
    if _model is None:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            print("  [알림] faster-whisper 미설치 → 자막 없이 진행 (pip install faster-whisper)")
            return None
        print(f"  Whisper 모델 로딩({name}) — 첫 실행은 모델 다운로드로 몇 분 걸립니다")
        _model = WhisperModel(name, device="cpu", compute_type="int8")
    return _model


def transcribe(p, model, lang):
    import numpy as np  # faster-whisper 의존성
    raw = subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-i", str(p), "-vn", "-ac", "1",
                          "-ar", "16000", "-f", "f32le", "-"], capture_output=True).stdout
    audio = np.frombuffer(raw, dtype=np.float32)
    if audio.size < 1600:
        return [], []
    segs, _ = model.transcribe(audio, language=lang or None, word_timestamps=True, vad_filter=True)
    out_s, words = [], []
    for s in segs:
        out_s.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()})
        for w in s.words or []:
            t = w.word.strip()
            if t:
                words.append({"start": round(w.start, 2), "end": round(w.end, 2), "word": t})
    return out_s, words


def cmd_analyze(a):
    init_bins()
    (WORK / "sheets").mkdir(parents=True, exist_ok=True)
    (WORK / "words").mkdir(parents=True, exist_ok=True)
    result = {"input": [], "reference": []}
    model = None
    proj = a.project or ""
    in_dir = INPUT / proj if proj else INPUT
    if proj and not in_dir.exists():
        sys.exit(f"[오류] input/{proj} 폴더가 없습니다.")
    ref_dir = REF / proj if proj and (REF / proj).exists() else REF
    pre = f"{safe_name(proj)}_" if proj else ""
    for kind, folder in (("input", in_dir), ("reference", ref_dir)):
        for i, f in enumerate(videos_in(folder), 1):
            info = probe(f)
            if not info:
                print(f"[건너뜀] {f.name} (영상 스트림 없음)")
                continue
            key = f"{pre}{kind[:3]}{i:02d}"
            dur = info["duration"]
            print(f"[{kind}] {key} {f.name}  {dur:.1f}s  {info['width']}x{info['height']}")
            cuts = detect_cuts(f, a.threshold)
            n = 12 if dur <= 45 else 24 if dur <= 180 else 36
            sheet = make_sheet(f, WORK / "sheets" / f"{key}_all.jpg", 0, dur, n)
            entry = {"key": key, "file": rel(f), "name": f.name, **info,
                     "cuts": cuts, "sheet": rel(sheet)}
            hook_d = min(3.0, dur)
            entry["hook_sheet"] = rel(make_sheet(f, WORK / "sheets" / f"{key}_hook.jpg", 0, hook_d, 12))
            if kind == "reference":
                b = [0.0] + [c for c in cuts if 0 < c < dur] + [dur]
                shots = [round(b[k + 1] - b[k], 2) for k in range(len(b) - 1) if b[k + 1] - b[k] > 0.05]
                srt = sorted(shots)
                entry["shots"] = shots
                entry["shot_stats"] = {"count": len(shots),
                                       "avg": round(sum(shots) / len(shots), 2) if shots else None,
                                       "median": srt[len(srt) // 2] if srt else None,
                                       "first_cut": cuts[0] if cuts else None}
            wfile = WORK / "words" / f"{fid(f)}.json"
            if info["has_audio"] and a.whisper:
                if wfile.exists():
                    data = json.loads(wfile.read_text(encoding="utf-8"))
                else:
                    model = model or get_model(a.model)
                    if model:
                        print("  음성 인식 중…")
                        segs, words = transcribe(f, model, a.lang)
                        data = {"segments": segs, "words": words}
                        wfile.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
                    else:
                        data = None
                if data:
                    entry["transcript"] = data["segments"]
            result[kind].append(entry)
    (WORK / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")

    # 사람/Claude가 읽기 쉬운 요약
    print("\n════ 분석 요약 ════ (상세: work/analysis.json)")
    for kind in ("input", "reference"):
        for e in result[kind]:
            print(f"\n[{e['key']}] {e['file']}  {e['duration']}s  {e['width']}x{e['height']}  "
                  f"오디오:{'O' if e['has_audio'] else 'X'}  컷:{len(e['cuts'])}개")
            print(f"  시트: {e['sheet']} | 첫3초: {e['hook_sheet']}")
            if e.get("shot_stats"):
                print(f"  샷 통계: {e['shot_stats']}")
                print(f"  샷 길이: {e['shots'][:30]}")
            for s in (e.get("transcript") or [])[:40]:
                print(f"  {s['start']:6.2f}-{s['end']:6.2f}  {s['text']}")
    if not result["input"]:
        print("\n[알림] input/ 폴더에 영상이 없습니다.")


def cmd_sheet(a):
    init_bins()
    src = Path(a.file)
    if not src.is_absolute():
        src = ROOT / src
    info = probe(src)
    start = a.start or 0.0
    end = min(a.end or info["duration"], info["duration"])
    (WORK / "sheets").mkdir(parents=True, exist_ok=True)
    out = WORK / "sheets" / f"{safe_name(src.stem)}_{start:.0f}-{end:.0f}.jpg"
    make_sheet(src, out, start, end - start, a.n)
    print(rel(out))


def cmd_overview(a):
    """폴더의 모든 영상을 영상당 한 줄(프레임 n장)로 모아 몇 장의 요약 이미지로 만든다 — 토큰 절약용."""
    init_bins()
    from PIL import Image, ImageDraw, ImageFont
    folder = INPUT / a.project if a.project else INPUT
    files = videos_in(folder)
    tmp = WORK / "ov_tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    tw, th = 120, 213
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/malgunbd.ttf", 18)
    except OSError:
        font = ImageFont.load_default()
    rows = []
    for i, f in enumerate(files, 1):
        dur = probe(f)["duration"]
        imgs = []
        for k in range(a.n):
            t = dur * (k + 0.5) / a.n
            out = tmp / f"{i:02d}_{k}.jpg"
            run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", f,
                 "-frames:v", "1", "-vf", f"scale={tw}:{th}:force_original_aspect_ratio=increase,crop={tw}:{th}", out])
            imgs.append((Image.open(out).copy(), t))
        rows.append((i, f.name, dur, imgs))
    label_w = 150
    out_paths = []
    for p in range(0, len(rows), a.rows):
        chunk = rows[p:p + a.rows]
        sheet = Image.new("RGB", (label_w + a.n * (tw + 4), len(chunk) * (th + 4)), "white")
        d = ImageDraw.Draw(sheet)
        for r, (i, name, dur, imgs) in enumerate(chunk):
            y = r * (th + 4)
            d.text((6, y + 10), f"#{i:02d}", fill="black", font=font)
            d.text((6, y + 40), f"{dur:.1f}s", fill="black", font=font)
            d.text((6, y + 70), name[-10:-4], fill="gray", font=font)
            for k, (im, t) in enumerate(imgs):
                x = label_w + k * (tw + 4)
                sheet.paste(im, (x, y))
                d.text((x + 3, y + 2), f"{t:.0f}s", fill="yellow", font=font, stroke_width=2, stroke_fill="black")
        out = WORK / "sheets" / f"{safe_name(a.project or 'input')}_overview{p // a.rows + 1}.jpg"
        out.parent.mkdir(parents=True, exist_ok=True)
        sheet.save(out, quality=82)
        out_paths.append(rel(out))
    shutil.rmtree(tmp, ignore_errors=True)
    for i, name, dur, _ in rows:
        print(f"#{i:02d} {name} {dur:.1f}s")
    print("\n".join(out_paths))


# ───────────────────────── 콜라주 커버 ─────────────────────────
def _frame(src, t):
    """원본 영상의 t초 프레임을 1080x1920(세로 꽉 차게)으로 가져온다."""
    from PIL import Image
    import tempfile
    tmp = Path(tempfile.gettempdir()) / f"shorts_frame_{fid(src)}_{t:.2f}.png"
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", src, "-frames:v", "1",
         "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}", tmp])
    im = Image.open(tmp).convert("RGB")
    tmp.unlink(missing_ok=True)
    return im


def make_cover_collage(plan, out_path):
    """cover_layout 대로 커버를 그린다.
    top/bottom: {"file","time","focus_y"(0~1, 기본 0.5),"zoom"(기본 1)} → 위·아래 1080x960 패널
    circle: {"file","time","cx","cy"(원본 프레임 안 중심, 0~1),"size"(원본에서 자를 지름 비율, 기본 0.75),
             "x","y"(커버 위 원 중심 px, 기본 790,1000),"d"(지름 px, 기본 460),"label"}
    헤드카피는 cover_text 또는 hook_text, 색은 hook_box."""
    from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
    lay = plan["cover_layout"]
    font_path = ROOT / "tools" / "fonts" / "Pretendard-ExtraBold.otf"
    canvas = Image.new("RGB", (W, H), "white")
    half = (H - 6) // 2

    def panel(spec, y_dst):
        im = _frame((ROOT / spec["file"]).resolve(), float(spec["time"]))
        z = float(spec.get("zoom", 1.0))
        if z > 1:
            im = im.resize((int(W * z), int(H * z)), Image.LANCZOS)
        im = ImageEnhance.Color(im).enhance(1.12)
        x0 = (im.width - W) // 2
        y0 = int((im.height - half) * float(spec.get("focus_y", 0.5)))
        canvas.paste(im.crop((x0, y0, x0 + W, y0 + half)), (0, y_dst))

    panel(lay["top"], 0)
    panel(lay["bottom"], half + 6)
    if lay.get("circle"):
        cs = lay["circle"]
        im = _frame((ROOT / cs["file"]).resolve(), float(cs["time"]))
        D = int(cs.get("d", 460))
        cx, cy = int(cs.get("x", 790)), int(cs.get("y", half + 40))
        r = float(cs.get("size", 0.75)) * W / 2
        sx, sy = float(cs.get("cx", 0.5)) * W, float(cs.get("cy", 0.5)) * H
        src = im.crop((int(sx - r), int(sy - r), int(sx + r), int(sy + r))).resize((D, D), Image.LANCZOS)
        mask = Image.new("L", (D, D), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, D - 1, D - 1), fill=255)
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(sh).ellipse((cx - D / 2 - 8, cy - D / 2 + 4, cx + D / 2 + 8, cy + D / 2 + 20), fill=(0, 0, 0, 110))
        canvas = Image.alpha_composite(canvas.convert("RGBA"), sh.filter(ImageFilter.GaussianBlur(14))).convert("RGB")
        d = ImageDraw.Draw(canvas)
        d.ellipse((cx - D / 2 - 12, cy - D / 2 - 12, cx + D / 2 + 12, cy + D / 2 + 12), fill="white")
        canvas.paste(src, (cx - D // 2, cy - D // 2), mask)
        if cs.get("label"):
            lf = ImageFont.truetype(str(font_path), 50)
            lw = d.textlength(cs["label"], font=lf)
            lx, ly = cx - lw / 2, cy + D / 2 - 18
            d.rounded_rectangle((lx - 26, ly - 12, lx + lw + 26, ly + 62), radius=36, fill="#FFE100")
            d.text((lx, ly - 2), cs["label"], font=lf, fill="black")
    d = ImageDraw.Draw(canvas)
    d.rectangle((0, half, W, half + 6), fill="white")

    # 헤드카피: [강조] → 강조색, | → 줄바꿈
    text = plan.get("cover_text") or plan.get("hook_text") or ""
    box = plan.get("hook_box", "black")
    fg, bg, hi = {"yellow": ("black", "#FFE100", "#E61E1E"), "white": ("black", "white", "#E61E1E")}.get(
        box, ("white", "black", "#FFE100"))
    font = ImageFont.truetype(str(font_path), int(plan.get("cover_size", 98)))
    asc, desc = font.getmetrics()
    lh = asc + desc
    y = int(plan.get("cover_y", 300))
    for line in text.split("|"):
        parts = [(p, hi if k % 2 else fg) for k, p in enumerate(re.split(r"[\[\]]", line)) if p]
        tw = sum(d.textlength(p, font=font) for p, _ in parts)
        x = (W - tw) / 2
        d.rectangle((x - 30, y - 18, x + tw + 30, y + lh + 12), fill=bg)
        for p, col in parts:
            d.text((x, y), p, font=font, fill=col)
            x += d.textlength(p, font=font)
        y += lh + 30
    canvas.save(out_path, quality=93)


# ───────────────────────── 얼굴 흐림 ─────────────────────────
def _cascades():
    """OpenCV 는 한글 경로의 파일을 못 열어서, 얼굴 검출 모델을 영문 임시 폴더로 복사해 쓴다."""
    import cv2
    import tempfile
    dst = Path(tempfile.gettempdir()) / "shorts_cascades"
    dst.mkdir(exist_ok=True)
    out = []
    for n in ("haarcascade_frontalface_default.xml", "haarcascade_profileface.xml"):
        t = dst / n
        if not t.exists():
            shutil.copy(Path(cv2.data.haarcascades) / n, t)
        c = cv2.CascadeClassifier(str(t))
        if c.empty():
            sys.exit(f"[오류] 얼굴 검출 모델을 열 수 없음: {t}")
        out.append(c)
    return out


def blur_face(seg, mode="upper", box=None):
    """seg 영상의 얼굴을 흐리게. mode=upper: 눈·이마만 (입은 보임), full: 얼굴 전체.
    box=[x,y,w,h] (0~1 비율)을 주면 검출 대신 그 위치를 고정으로 흐림."""
    import cv2
    import numpy as np
    n_bytes = W * H * 3
    dec = subprocess.Popen([FFMPEG, "-hide_banner", "-loglevel", "error", "-i", str(seg),
                            "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], stdout=subprocess.PIPE)
    frames = []
    while True:
        b = dec.stdout.read(n_bytes)
        if len(b) < n_bytes:
            break
        frames.append(np.frombuffer(b, np.uint8).reshape(H, W, 3).copy())
    dec.wait()
    if not frames:
        return 0

    boxes = [None] * len(frames)
    if box:
        fixed = (box[0] * W, box[1] * H, box[2] * W, box[3] * H)
        boxes = [fixed] * len(frames)
    else:
        front, prof = _cascades()
        sc = 3
        for i, fr in enumerate(frames):
            g = cv2.equalizeHist(cv2.cvtColor(cv2.resize(fr, (W // sc, H // sc)), cv2.COLOR_BGR2GRAY))
            found = list(front.detectMultiScale(g, 1.1, 5, minSize=(40, 40)))
            if not found:
                found = list(prof.detectMultiScale(g, 1.1, 4, minSize=(40, 40)))
            if not found:
                gf = cv2.flip(g, 1)
                found = [(g.shape[1] - x - w, y, w, h) for x, y, w, h in prof.detectMultiScale(gf, 1.1, 4, minSize=(40, 40))]
            if found:
                x, y, w, h = max(found, key=lambda r: r[2] * r[3])
                boxes[i] = (x * sc, y * sc, w * sc, h * sc)
        hits = [i for i, b in enumerate(boxes) if b]
        # 잘못 잡은 위치 제거: 중앙값에서 크게 벗어난 검출은 버림
        if hits:
            import statistics as st
            mcx = st.median(boxes[i][0] + boxes[i][2] / 2 for i in hits)
            mcy = st.median(boxes[i][1] + boxes[i][3] / 2 for i in hits)
            mw = st.median(boxes[i][2] for i in hits)
            for i in hits:
                x, y, w, h = boxes[i]
                if abs(x + w / 2 - mcx) > 0.8 * mw or abs(y + h / 2 - mcy) > 0.8 * mw or not 0.6 * mw < w < 1.6 * mw:
                    boxes[i] = None
            hits = [i for i, b in enumerate(boxes) if b]
        if len(hits) < max(3, 0.15 * len(frames)):
            print(f"  [경고] 얼굴이 거의 검출되지 않음({len(hits)}/{len(frames)}프레임) → 흐림 생략. "
                  "얼굴이 보이면 plan 에 blur_box 로 위치를 지정하세요")
            return 0
        # 빈 프레임 채우기: 앞뒤 검출 사이 선형 보간, 처음/끝은 가장 가까운 값 유지
        for i in range(len(boxes)):
            if boxes[i]:
                continue
            prv = max((j for j in hits if j < i), default=None)
            nxt = min((j for j in hits if j > i), default=None)
            if prv is None:
                boxes[i] = boxes[nxt]
            elif nxt is None:
                boxes[i] = boxes[prv]
            else:
                r = (i - prv) / (nxt - prv)
                boxes[i] = tuple(boxes[prv][k] * (1 - r) + boxes[nxt][k] * r for k in range(4))
        # 떨림 줄이기: 이동 평균
        sm = []
        for i in range(len(boxes)):
            win = boxes[max(0, i - 3): i + 4]
            sm.append(tuple(sum(b[k] for b in win) / len(win) for k in range(4)))
        boxes = sm

    enc = subprocess.Popen([FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                            "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-i", str(seg), "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "veryfast",
                            "-crf", "17", "-pix_fmt", "yuv420p", "-c:a", "copy", "-shortest",
                            str(seg.with_name(seg.stem + "_b.mp4"))], stdin=subprocess.PIPE)
    for fr, (x, y, w, h) in zip(frames, boxes):
        if mode == "upper" and not box:
            # 눈·이마·머리만: 얼굴 박스 위로 30% 확장 ~ 코 아래(얼굴 높이 62%)까지
            x0, x1 = x - 0.28 * w, x + 1.28 * w
            y0, y1 = y - 0.45 * h, y + 0.64 * h
        elif box:
            x0, x1, y0, y1 = x, x + w, y, y + h
        else:
            x0, x1 = x - 0.15 * w, x + 1.15 * w
            y0, y1 = y - 0.3 * h, y + 1.1 * h
        x0, y0 = max(0, int(x0)), max(0, int(y0))
        x1, y1 = min(W, int(x1)), min(H, int(y1))
        if x1 - x0 > 4 and y1 - y0 > 4:
            roi = fr[y0:y1, x0:x1]
            # 강한 흐림: 축소 후 확대(모자이크 느낌) + 가우시안
            rw, rh = x1 - x0, y1 - y0
            small = cv2.resize(roi, (max(1, rw // 14), max(1, rh // 14)), interpolation=cv2.INTER_AREA)
            big = cv2.resize(small, (rw, rh), interpolation=cv2.INTER_LINEAR)
            k = max(21, int(rw / 4) | 1)
            fr[y0:y1, x0:x1] = cv2.GaussianBlur(big, (k, k), 0)
        enc.stdin.write(fr.tobytes())
    enc.stdin.close()
    enc.wait()
    seg.with_name(seg.stem + "_b.mp4").replace(seg)
    return len(hits) if not box else len(frames)


# ───────────────────────── 자막(ASS) ─────────────────────────
def ass_time(t):
    t = max(0.0, t)
    cs = int(round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def ass_escape(s):
    return s.replace("\\", "＼").replace("{", "(").replace("}", ")")


RED = "&H1E1EE6&"
BLACK = "&H000000&"
# 헤드카피 박스 스타일: (글자색, 박스색, 강조색)  — ASS 색은 &HAABBGGRR
BOX_STYLES = {
    "yellow": ("&H00000000", "&H0000E1FF", RED),
    "white": ("&H00000000", "&H00FFFFFF", RED),
    "black": ("&H00FFFFFF", "&H1A000000", YELLOW),
}


def emphasize(s, hi=YELLOW, base=WHITE):
    """[강조] 표시 → 강조색, 줄바꿈(\\n 또는 |) → ASS 줄바꿈"""
    s = ass_escape(s).replace("|", "\n")
    s = re.sub(r"\[([^\]]+)\]", lambda m: "{\\c" + hi + "}" + m.group(1) + "{\\c" + base + "}", s)
    return s.replace("\n", "\\N")


def build_ass(plan, timeline, total, words_by_clip):
    default_font = "Pretendard ExtraBold" if any((ROOT / "tools" / "fonts").glob("Pretendard*")) else "Malgun Gothic"
    font = plan.get("font", default_font)
    cap_size = int(plan.get("caption_size", 84))
    box = plan.get("hook_box")  # None | yellow | white | black
    if box in BOX_STYLES:
        h_txt, h_box, h_hi = BOX_STYLES[box]
        hook_style = f"{h_txt},&H000000FF,{h_box},&H00000000,-1,0,0,0,100,100,0,0,3,22,0"
        h_base = "&H" + h_txt[-6:] + "&"
    else:
        hook_style = "&H00FFFFFF,&H000000FF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,9,4"
        h_hi, h_base = YELLOW, WHITE
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{font},{cap_size},&H00FFFFFF,&H000000FF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,7,3,2,90,90,{int(plan.get('caption_margin', 560))},1
Style: Hook,{font},{int(plan.get('hook_size', 100))},{hook_style},8,70,70,{int(plan.get('hook_margin', 330))},1
Style: Over,{font},74,&H00FFFFFF,&H000000FF,&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,7,3,8,70,70,{int(plan.get('hook_margin', 330))},1
Style: CTA,{font},86,&H00FFFFFF,&H000000FF,&H33000000,&H00000000,-1,0,0,0,100,100,0,0,3,24,0,5,70,70,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []

    def add(st, en, style, text, layer=0):
        if en - st > 0.02:
            ev.append(f"Dialogue: {layer},{ass_time(st)},{ass_time(en)},{style},,0,0,0,,{text}")

    pop = "{\\fscx82\\fscy82\\t(0,110,\\fscx100\\fscy100)}"

    # 1) 훅 문구 (첫 화면)
    hook = plan.get("hook_text")
    hook_d = float(plan.get("hook_duration", 2.5))
    if hook:
        # hook_hide: [[시작, 끝], ...] 완성본 기준 초 — 이 구간엔 헤드카피를 숨김 (피사체 가림 방지)
        spans, cur = [], 0.0
        for hs, he in sorted((float(a), float(b)) for a, b in plan.get("hook_hide", [])):
            spans.append((cur, hs))
            cur = max(cur, he)
        spans.append((cur, min(hook_d, total)))
        for k, (st, en) in enumerate(spans):
            add(st, min(en, total), "Hook", (pop if k == 0 else "") + emphasize(hook, h_hi, h_base), 2)

    # 2) 클립별 오버레이 문구
    for seg, c in zip(timeline, plan["clips"]):
        if c.get("text"):
            st = max(seg["t0"], hook_d if hook else 0)
            add(st, seg["t1"], "Over", pop + emphasize(c["text"]), 2)

    # 3) 말자막: custom_captions 우선, 없으면 음성인식 단어로 카라오케식 자막
    if plan.get("custom_captions") or plan.get("narration"):
        for cc in plan.get("custom_captions") or plan["narration"]:
            add(float(cc["start"]), min(float(cc["end"]), total), "Cap", pop + emphasize(cc["text"]), 1)
    elif plan.get("captions", True):
        max_words = int(plan.get("caption_words", 3))
        max_chars = int(plan.get("caption_chars", 14))
        allw = []
        for seg, ws in zip(timeline, words_by_clip):
            for w in ws:
                if w["end"] <= seg["src_s"] + 0.05 or w["start"] >= seg["src_e"] - 0.05:
                    continue
                t0 = seg["t0"] + (max(w["start"], seg["src_s"]) - seg["src_s"]) / seg["speed"]
                t1 = seg["t0"] + (min(w["end"], seg["src_e"]) - seg["src_s"]) / seg["speed"]
                word = re.sub(r"[.,…]+$", "", w["word"]).strip()
                if word:
                    allw.append({"t0": t0, "t1": min(t1, seg["t1"]), "w": word, "clip": seg["i"]})
        chunks, cur = [], []
        for w in allw:
            if cur and (len(cur) >= max_words
                        or len(" ".join(x["w"] for x in cur + [w])) > max_chars
                        or w["t0"] - cur[-1]["t1"] > 0.6 or w["clip"] != cur[-1]["clip"]):
                chunks.append(cur)
                cur = []
            cur.append(w)
        if cur:
            chunks.append(cur)
        for ci, ch in enumerate(chunks):
            nxt = chunks[ci + 1][0]["t0"] if ci + 1 < len(chunks) else total
            chunk_end = min(ch[-1]["t1"] + 0.3, nxt)
            for wi, w in enumerate(ch):
                st = w["t0"] if wi else ch[0]["t0"]
                en = ch[wi + 1]["t0"] if wi + 1 < len(ch) else chunk_end
                parts = []
                for k, x in enumerate(ch):
                    t = ass_escape(x["w"])
                    parts.append("{\\c" + YELLOW + "}" + t + "{\\c" + WHITE + "}" if k == wi else t)
                add(st, en, "Cap", (pop if wi == 0 else "") + " ".join(parts), 1)

    # 4) 마지막 CTA (팔로우 유도)
    cta = plan.get("cta_text")
    if cta:
        cd = float(plan.get("cta_duration", 2.5))
        add(max(0, total - cd), total, "CTA", pop + emphasize(cta), 3)
    return head + "\n".join(ev) + "\n"


# ───────────────────────── 렌더 ─────────────────────────
def cmd_render(a):
    init_bins()
    plan_path = Path(a.plan)
    if not plan_path.is_absolute():
        plan_path = ROOT / plan_path
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    title = safe_name(plan.get("title") or plan_path.stem)
    max_d = float(plan.get("max_duration", 30))
    segdir = WORK / "render" / title
    if segdir.exists():
        shutil.rmtree(segdir)
    segdir.mkdir(parents=True)
    outdir = OUT / safe_name(plan["project"]) if plan.get("project") else OUT
    outdir.mkdir(parents=True, exist_ok=True)

    timeline, words_by_clip, t = [], [], 0.0
    for i, c in enumerate(plan["clips"]):
        src = (ROOT / c["file"]).resolve()
        info = probe(src)
        s = max(0.0, float(c["start"]))
        e = min(float(c["end"]), info["duration"])
        if e - s < 0.2:
            sys.exit(f"[오류] 클립 {i} 구간이 너무 짧거나 잘못됨: {c}")
        speed = min(2.0, max(0.5, float(c.get("speed", 1.0))))
        zoom = max(1.0, float(c.get("zoom", 1.0)))
        fx, fy = float(c.get("focus_x", 0.5)), float(c.get("focus_y", 0.5))
        vf = (f"scale={even(W * zoom)}:{even(H * zoom)}:force_original_aspect_ratio=increase,"
              f"crop={W}:{H}:(iw-{W})*{fx}:(ih-{H})*{fy},setsar=1,fps={FPS},format=yuv420p")
        if speed != 1:
            vf = f"setpts=PTS/{speed}," + vf
        if c.get("flip"):
            vf += ",hflip"
        out_d = (e - s) / speed
        cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
               "-ss", f"{s:.3f}", "-t", f"{e - s:.3f}", "-i", src]
        if info["has_audio"] and c.get("audio", True) and not plan.get("mute"):
            af = "aresample=48000,aformat=channel_layouts=stereo"
            if speed != 1:
                af = f"atempo={speed}," + af
            vol = float(c.get("volume", 1.0))
            if vol != 1:
                af += f",volume={vol}"
            fc = f"[0:v]{vf}[v];[0:a]{af}[a]"
        else:
            cmd += ["-f", "lavfi", "-t", f"{out_d:.3f}", "-i", "anullsrc=r=48000:cl=stereo"]
            fc = f"[0:v]{vf}[v];[1:a]anull[a]"
        seg = segdir / f"seg_{i:02d}.mp4"
        cmd += ["-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-t", f"{out_d:.3f}",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "17",
                "-c:a", "aac", "-b:a", "192k", "-ar", "48000", seg]
        print(f"  컷 {i + 1}/{len(plan['clips'])}: {Path(c['file']).name} {s:.2f}→{e:.2f}s")
        run(cmd)
        if c.get("blur_face") or c.get("blur_box"):
            nhit = blur_face(seg, c.get("blur_face") or "upper", c.get("blur_box"))
            print(f"    얼굴 흐림 적용 (검출 프레임 {nhit})")
        real = probe(seg)["duration"] or out_d
        timeline.append({"i": i, "t0": t, "t1": t + real, "src_s": s, "src_e": e, "speed": speed})
        t += real
        wf = WORK / "words" / f"{fid(src)}.json"
        words_by_clip.append(json.loads(wf.read_text(encoding="utf-8"))["words"] if wf.exists() else [])

    total = min(t, max_d)
    if t > max_d + 0.05:
        print(f"  [알림] 합계 {t:.1f}s → {max_d:.0f}s 로 자릅니다")

    (segdir / "list.txt").write_text("".join(f"file 'seg_{i:02d}.mp4'\n" for i in range(len(timeline))),
                                     encoding="utf-8")
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0",
         "-i", "list.txt", "-c", "copy", "joined.mp4"], cwd=segdir)

    (segdir / "captions.ass").write_text(build_ass(plan, timeline, total, words_by_clip), encoding="utf-8-sig")

    inputs = ["-i", "joined.mp4"]
    norm = "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000"
    music = plan.get("music")
    if music:
        mpath = (ROOT / music).resolve()
        inputs += ["-stream_loop", "-1", "-i", mpath]
        mv = float(plan.get("music_volume", 0.25))
        mfade = f"afade=t=out:st={max(0, total - 1):.2f}:d=1"
        if plan.get("keep_original_audio", True):
            afc = (f"[0:a]asplit=2[voice][sc];"
                   f"[1:a]atrim=0:{total:.3f},asetpts=N/SR/TB,volume={mv},{mfade}[m];"
                   f"[m][sc]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=350[md];"
                   f"[voice][md]amix=inputs=2:duration=first:normalize=0,{norm}[a]")
        else:
            afc = f"[1:a]atrim=0:{total:.3f},asetpts=N/SR/TB,volume={mv},{mfade},{norm}[a]"
    else:
        afc = f"[0:a]{norm}[a]"
    fontdir = ROOT / "tools" / "fonts"
    sub = "subtitles=captions.ass"
    if fontdir.exists() and any(fontdir.iterdir()):
        shutil.copytree(fontdir, segdir / "fonts", dirs_exist_ok=True)
        sub += ":fontsdir=fonts"
    fc = f"[0:v]{sub}[v];{afc}"
    final = outdir / f"{title}.mp4"
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", *inputs, "-filter_complex", fc,
         "-map", "[v]", "-map", "[a]", "-t", f"{total:.3f}",
         "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-profile:v", "high",
         "-pix_fmt", "yuv420p", "-r", str(FPS), "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
         "-movflags", "+faststart", final], cwd=segdir)

    cover_t = min(float(plan.get("cover_time", 0.8)), max(0, total - 0.1))
    cover = outdir / f"{title}_cover.jpg"
    # 커버(썸네일): 자막·CTA 없이 헤드카피만 (cover_text 가 있으면 그 문구로)
    cplan = {k: v for k, v in plan.items() if k not in ("custom_captions", "narration", "cta_text", "hook_hide")}
    cplan["captions"] = False
    cplan["hook_duration"] = 99
    if plan.get("cover_text"):
        cplan["hook_text"] = plan["cover_text"]
    cass = build_ass(cplan, timeline, 99, words_by_clip).replace("{\\fscx82\\fscy82\\t(0,110,\\fscx100\\fscy100)}", "")
    (segdir / "cover.ass").write_text(cass, encoding="utf-8-sig")
    csub = "subtitles=cover.ass" + (":fontsdir=fonts" if (segdir / "fonts").exists() else "")
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{cover_t:.2f}", "-i", "joined.mp4",
         "-vf", csub, "-frames:v", "1", "-q:v", "2", cover], cwd=segdir)
    if plan.get("cover_layout"):
        make_cover_collage(plan, cover)

    # 나레이션 대본 → SRT (캡컷 등에서 '텍스트 음성 변환'으로 목소리 입힐 때 사용)
    if plan.get("narration"):
        def srt_t(t):
            ms = int(round(t * 1000))
            return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"
        srt = []
        for k, nar in enumerate(plan["narration"], 1):
            txt = re.sub(r"[\[\]]", "", nar["text"]).replace("|", " ")
            srt += [str(k), f"{srt_t(float(nar['start']))} --> {srt_t(min(float(nar['end']), total))}", txt, ""]
        (outdir / f"{title}_narration.srt").write_text("\n".join(srt), encoding="utf-8")
        (outdir / f"{title}_narration.txt").write_text(
            "\n".join(re.sub(r"[\[\]]", "", n["text"]).replace("|", " ") for n in plan["narration"]), encoding="utf-8")
        print(f"나레이션: {rel(outdir / f'{title}_narration.srt')}")
        # 캡컷용: 글자 없는 컷(흐림·크롭·음소거 적용) + 나레이션 SRT
        cdir = outdir / "캡컷용"
        if cdir.exists():
            shutil.rmtree(cdir)
        cdir.mkdir()
        for k in range(len(timeline)):
            shutil.copy(segdir / f"seg_{k:02d}.mp4", cdir / f"{k + 1:02d}.mp4")
        shutil.copy(outdir / f"{title}_narration.srt", cdir / "나레이션.srt")
        shutil.copy(final, cdir / "완성본_음소거.mp4")
        print(f"캡컷용: {rel(cdir)}")

    lines = []
    if plan.get("caption"):
        lines += [plan["caption"].strip(), ""]
    if plan.get("hashtags"):
        lines += [" ".join(h if h.startswith("#") else "#" + h for h in plan["hashtags"]), ""]
    if plan.get("first_comment"):
        lines += ["[첫 댓글로 달기]", plan["first_comment"].strip(), ""]
    if plan.get("posting_tips"):
        lines += ["[업로드 팁]", *[f"- {x}" for x in plan["posting_tips"]]]
    if lines:
        (outdir / f"{title}_caption.txt").write_text("\n".join(lines), encoding="utf-8")

    print(f"\n완성: {rel(final)}  ({total:.1f}s, {W}x{H})")
    print(f"커버: {rel(cover)}")
    if lines:
        print(f"캡션: {rel(outdir / f'{title}_caption.txt')}")


# ───────────────────────── 점검 ─────────────────────────
def cmd_check(_a):
    ok = True
    for b in ("ffmpeg", "ffprobe"):
        local = ROOT / "tools" / "ffmpeg" / "bin" / f"{b}.exe"
        p = str(local) if local.exists() else shutil.which(b)
        print(f"{b:9s}: {p or '없음'}")
        ok &= bool(p)
    if ok:
        init_bins()
        filters = run([FFMPEG, "-hide_banner", "-filters"]).stdout
        has = all(x in filters for x in ("subtitles", "sidechaincompress", "loudnorm", "drawtext"))
        print(f"필터     : {'OK' if has else '부족 (libass/drawtext 포함 빌드 필요)'}")
        ok &= has
    for mod, label, need in (("cv2", "OpenCV   ", True), ("PIL", "Pillow   ", True), ("numpy", "numpy    ", True),
                             ("pypdfium2", "PDF읽기  ", False), ("faster_whisper", "음성인식 ", False)):
        try:
            __import__(mod)
            print(f"{label}: OK")
        except ImportError:
            print(f"{label}: 없음" + (" → setup.ps1 다시 실행" if need else " (선택 기능)"))
            ok &= not need
    pre = ROOT / "tools" / "fonts" / "Pretendard-ExtraBold.otf"
    print(f"글꼴     : {'프리텐다드 OK' if pre.exists() else '프리텐다드 없음 → setup.ps1 (맑은 고딕으로 대체)'}")
    for d in (INPUT, REF, MUSIC, OUT):
        if not d.exists():
            print(f"{d.name:9s}: 폴더 없음")
            continue
        subs = [s for s in d.iterdir() if s.is_dir()]
        print(f"{d.name:9s}: 영상 {len(videos_in(d))}개" + (f", 하위 폴더 {len(subs)}개" if subs else ""))
    print("\n준비 완료" if ok else "\n설치가 더 필요합니다 (setup.ps1)")


def main():
    ap = argparse.ArgumentParser(description="바이럴 숏츠 메이커")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("analyze", help="input/ reference/ 영상 분석")
    p.add_argument("project", nargs="?", help="input/ 아래 폴더 이름 (예: [가림1])")
    p.add_argument("--threshold", type=float, default=0.3, help="컷 감지 민감도 (낮을수록 많이 감지)")
    p.add_argument("--model", default="small", help="whisper 모델: base/small/medium")
    p.add_argument("--lang", default="ko")
    p.add_argument("--whisper", action="store_true", help="음성인식으로 대사 추출 (기본: 안 함)")
    p.set_defaults(fn=cmd_analyze)
    p = sub.add_parser("render", help="편집 계획(json)으로 렌더링")
    p.add_argument("plan")
    p.set_defaults(fn=cmd_render)
    p = sub.add_parser("sheet", help="영상 구간 썸네일 시트")
    p.add_argument("file")
    p.add_argument("--start", type=float)
    p.add_argument("--end", type=float)
    p.add_argument("--n", type=int, default=12)
    p.set_defaults(fn=cmd_sheet)
    p = sub.add_parser("overview", help="폴더 전체 영상을 몇 장의 요약 이미지로")
    p.add_argument("project", nargs="?")
    p.add_argument("--n", type=int, default=5, help="영상당 프레임 수")
    p.add_argument("--rows", type=int, default=10, help="이미지 한 장당 영상 수")
    p.set_defaults(fn=cmd_overview)
    p = sub.add_parser("check", help="설치 점검")
    p.set_defaults(fn=cmd_check)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
