r"""
숏폼 검수 도구 — 렌더 결과를 CLAUDE.md 규칙으로 자동 채점하고, 눈으로 볼 확인 이미지 3장을 만든다.

사용:  .\tools\python\python.exe tools\review.py plans/<매장>/<제목>.json
결과:  work/review/<제목>/report.md  (자동 채점표)
       work/review/<제목>/1_sheet.jpg  (완성본 18장 요약)
       work/review/<제목>/2_blur.jpg   (얼굴 흐림 컷 위쪽 확대 — 아이 눈 확인용)
       work/review/<제목>/3_cover.jpg  (커버 원본 | 3:4 프로필 그리드 미리보기)
판정(통과/수정 필요)은 검수 에이전트(.claude/agents/shorts-reviewer.md)가 이 결과를 보고 내린다.
"""
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import shorts as S  # noqa: E402  (같은 폴더의 편집 엔진 — 경로·ffmpeg·probe 재사용)

OK, WARN, FAIL, LOOK = "✅", "⚠️", "❌", "👀"


def hangul_count(s):
    s = re.sub(r"[\[\]|]", "", s)
    return len(re.findall(r"[가-힣0-9A-Za-z]", s))


def clean(s):
    return re.sub(r"[\[\]]", "", s or "").replace("|", " ")


def max_volume(video):
    r = subprocess.run([S.FFMPEG, "-hide_banner", "-nostats", "-i", str(video), "-af", "volumedetect",
                        "-vn", "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.search(r"max_volume:\s*(-?[\d.]+|-inf)", r.stderr)
    if not m:
        return None
    return -999.0 if m.group(1) == "-inf" else float(m.group(1))


def grab(video, t, tmpdir, name):
    out = Path(tmpdir) / f"{name}.png"
    S.run([S.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{max(0, t):.2f}", "-i", video,
           "-frames:v", "1", out])
    return out


def build_timeline(plan):
    """render 와 같은 방식으로 각 컷이 완성본 몇 초에 놓이는지 계산 (원본 길이로 잘림 반영)."""
    tl, t = [], 0.0
    for i, c in enumerate(plan["clips"]):
        src = (S.ROOT / c["file"]).resolve()
        info = S.probe(src) if src.exists() else None  # 원본이 없으면 plan 숫자로 계산
        s = max(0.0, float(c["start"]))
        e = min(float(c["end"]), info["duration"] if info else float(c["end"]))
        sp = min(2.0, max(0.5, float(c.get("speed", 1.0))))
        d = (e - s) / sp
        tl.append({"i": i, "t0": t, "t1": t + d, "dur": d, "clip": c})
        t += d
    return tl


def main():
    if len(sys.argv) < 2:
        sys.exit("사용: python tools/review.py plans/<매장>/<제목>.json")
    S.init_bins()
    from PIL import Image, ImageDraw, ImageFont

    plan_path = Path(sys.argv[1])
    if not plan_path.is_absolute():
        plan_path = S.ROOT / plan_path
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    title = S.safe_name(plan.get("title") or plan_path.stem)
    outdir = S.OUT / S.safe_name(plan["project"]) if plan.get("project") else S.OUT
    video = outdir / f"{title}.mp4"
    cover = outdir / f"{title}_cover.jpg"
    capfile = outdir / f"{title}_caption.txt"
    rdir = S.WORK / "review" / title
    rdir.mkdir(parents=True, exist_ok=True)
    font_p = S.ROOT / "tools" / "fonts"
    font_file = next(iter(sorted(font_p.glob("*ExtraBold*"))), None) or next(iter(font_p.glob("*.otf")), None)

    rows = []  # (구분, 결과, 항목, 내용)

    def add(cat, res, item, detail=""):
        rows.append((cat, res, item, detail))

    # ── 1. 파일 ──
    for p, name in [(video, "완성본"), (cover, "커버"), (capfile, "캡션")]:
        add("파일", OK if p.exists() else FAIL, name, S.rel(p))
    if plan.get("narration"):
        srt = outdir / f"{title}_narration.srt"
        add("파일", OK if srt.exists() else FAIL, "나레이션 SRT", S.rel(srt))
        add("파일", OK if (outdir / "캡컷용").exists() else FAIL, "캡컷용 폴더")
    if not video.exists():
        (rdir / "report.md").write_text("완성본이 없습니다. 먼저 render 하세요.\n", encoding="utf-8")
        print("완성본 없음 → render 먼저")
        return

    # ── 2. 영상 ──
    info = S.probe(video)
    total = info["duration"]
    add("영상", OK if 21 <= total <= 30.5 else FAIL, "길이 21~30초", f"{total:.1f}초")
    add("영상", OK if (info["width"], info["height"]) == (1080, 1920) else FAIL, "화면 1080×1920",
        f"{info['width']}×{info['height']}")
    if plan.get("mute"):
        mv = max_volume(video)
        add("영상", OK if mv is not None and mv <= -80 else FAIL, "무음(나레이션용)",
            f"최대 {mv:.1f}dB" if mv is not None and mv > -999 else "완전 무음")
    tl = build_timeline(plan)
    bad = [f"{x['i'] + 1}번 {x['dur']:.1f}s" for x in tl if not (1.0 <= x["dur"] <= 2.8)]
    add("영상", OK if not bad else WARN, "컷 길이 1.2~2.2초", f"{len(tl)}컷" + (f" / 벗어남: {', '.join(bad)}" if bad else ""))

    # ── 3. 헤드카피·CTA ──
    hook = plan.get("hook_text", "")
    if hook:
        n = len(re.sub(r"[\[\]|\s]", "", hook))
        lines = hook.split("|")
        add("헤드카피", OK if 12 <= n <= 18 else WARN, "12~18자", f"{n}자 「{clean(hook)}」")
        add("헤드카피", OK if len(lines) == 2 else WARN, "2줄", f"{len(lines)}줄")
        add("헤드카피", OK if "[" in hook else WARN, "노랑 강조 있음")
        add("헤드카피", LOOK, "핵심 피사체(음식·간판·얼굴) 가림 여부", "1_sheet.jpg 에서 확인 → 가리면 hook_hide")
    else:
        add("헤드카피", FAIL, "헤드카피 없음")
    cta = plan.get("cta_text", "")
    add("CTA", OK if re.search(r"저장|공유", cta) else FAIL, "[저장]/[공유] CTA", clean(cta) or "없음")
    if re.search(r"댓글", cta + plan.get("caption", "")):
        add("CTA", WARN, "댓글 유도 문구", "뻔한 댓글 유도는 금지 — 확인")

    # ── 4. 협찬·금지어 (화면에 들어가는 글자) ──
    screen = " ".join([hook, cta, plan.get("cover_text", "")] + [n["text"] for n in plan.get("narration", [])]
                      + [str((plan.get("cover_layout") or {}).get("circle", {}).get("label", ""))]
                      + [c.get("text", "") for c in plan.get("custom_captions", [])])
    add("규칙", FAIL if "협찬" in screen else OK, "화면에 '협찬' 글자 없음")
    loss = screen.count("손해")
    add("규칙", WARN if loss > 1 else OK, "'손해' 반복 안 함", f"{loss}회")

    # ── 5. 나레이션 ──
    nar = plan.get("narration") or []
    if nar:
        syl = sum(hangul_count(x["text"]) for x in nar)
        add("나레이션", OK if 100 <= syl <= 130 else WARN, "총 100~130음절", f"{syl}음절")
        add("나레이션", OK if 6 <= len(nar) <= 10 else WARN, "8문장 안팎", f"{len(nar)}문장")
        odd = [f"{k + 1}번 {float(x['end']) - float(x['start']):.1f}s" for k, x in enumerate(nar)
               if not (2.3 <= float(x["end"]) - float(x["start"]) <= 4.2)]
        add("나레이션", OK if not odd else WARN, "문장당 2.5~4초", ", ".join(odd))
        over = [f"{k + 1}번" for k in range(1, len(nar)) if float(nar[k]["start"]) < float(nar[k - 1]["end"]) - 0.05]
        add("나레이션", OK if not over else FAIL, "문장끼리 안 겹침", ", ".join(over))
        add("나레이션", OK if float(nar[-1]["end"]) <= total + 0.05 else FAIL, "영상 안에서 끝남",
            f"마지막 {float(nar[-1]['end']):.1f}s / 영상 {total:.1f}s")
        add("나레이션", LOOK, "첫 문장 = 헤드카피 메시지 = 0초 화면", f"「{clean(nar[0]['text'])}」")

    # ── 6. 캡션 ──
    cap = plan.get("caption", "")
    tags = plan.get("hashtags", [])
    if cap:
        first = cap.strip().splitlines()[0]
        add("캡션", OK if "협찬" in first else FAIL, "첫 줄(도입)에 [협찬] 표기", first[:40] + "…")
        if nar:
            n0 = re.sub(r"[^가-힣]", "", clean(nar[0]["text"]))[:8]
            add("캡션", OK if n0 and n0 in re.sub(r"[^가-힣]", "", first) else WARN, "도입 = 0초 나레이션 문장")
        add("캡션", OK if plan.get("project", "@@") in cap else WARN, "도입에 매장명")
        pts = [e for e in ("1️⃣", "2️⃣", "3️⃣") if e in cap]
        add("캡션", OK if len(pts) == 3 else FAIL, "추천 포인트 1️⃣2️⃣3️⃣", f"{len(pts)}개")
        add("캡션", OK if "[저장📌]" in cap and "[공유✈️]" in cap else FAIL, "[저장📌]·[공유✈️] 문장")
        add("캡션", OK if "📍" in cap else FAIL, "📍 매장 정보")
        prices = re.findall(r"[\d,]{3,}\s*원", cap)
        if prices:
            add("캡션", LOOK, "가격 — 메뉴판에서 확인한 것만", ", ".join(prices))
    else:
        add("캡션", FAIL, "plan 에 caption 없음")
    add("해시태그", OK if 8 <= len(tags) <= 10 else WARN, "8~10개", f"{len(tags)}개")
    add("해시태그", OK if "#협찬" in tags else FAIL, "#협찬 포함")
    proj = re.sub(r"\s", "", plan.get("project", ""))
    add("해시태그", OK if any(proj and proj in t for t in tags) else WARN, "매장명 태그")
    add("해시태그", OK if any(re.search(r"미사|망월|하남", t) for t in tags) else WARN, "지역 태그")

    # ── 7. 아이 보호·커버 ──
    blur = [x for x in tl if x["clip"].get("blur_face") or x["clip"].get("blur_box")]
    blur_files = {x["clip"]["file"] for x in blur}
    cl = plan.get("cover_layout") or {}
    add("커버", OK if cl else WARN, "콜라주 커버(cover_layout)", "없으면 영상 프레임 그대로라 규칙 7 위반 소지")
    face_cover = [k for k, v in cl.items() if isinstance(v, dict) and v.get("file") in blur_files]
    add("커버", FAIL if face_cover else OK, "커버에 얼굴(흐림 대상) 장면 안 씀", ", ".join(face_cover))
    add("커버", LOOK, "헤드카피·음식이 3:4 그리드에서도 보이는지", "3_cover.jpg 오른쪽")
    if blur:
        add("아이 보호", LOOK, "흐림 컷 눈 가려졌는지 (입은 보여야 함)",
            ", ".join(f"{x['i'] + 1}번({x['t0']:.1f}~{x['t1']:.1f}s)" for x in blur) + " → 2_blur.jpg")
    else:
        add("아이 보호", LOOK, "흐림 지정 컷 없음", "1_sheet.jpg 에 아이 얼굴이 보이면 ❌")

    # ── 이미지 3장 ──
    with tempfile.TemporaryDirectory() as td:
        # 1) 완성본 18장 요약
        S.make_sheet(str(video), str(rdir / "1_sheet.jpg"), 0, total, 18, cols=6)

        # 2) 흐림 컷: 컷마다 3프레임, 위쪽 60% 확대
        fnt = ImageFont.truetype(str(font_file), 30) if font_file else ImageFont.load_default()
        if blur:
            cw, ch = 420, int(1920 * 0.6 * 420 / 1080)
            board = Image.new("RGB", (cw * 3 + 16, (ch + 8) * len(blur) + 8), "black")
            for r, x in enumerate(blur):
                for k, f in enumerate((0.15, 0.5, 0.85)):
                    t = x["t0"] + (x["t1"] - x["t0"]) * f
                    im = Image.open(grab(str(video), t, td, f"b{r}{k}")).convert("RGB")
                    im = im.crop((0, 0, im.width, int(im.height * 0.6))).resize((cw, ch))
                    ImageDraw.Draw(im).text((8, 8), f"{x['i'] + 1}번 {t:.1f}s", font=fnt, fill="yellow",
                                            stroke_width=3, stroke_fill="black")
                    board.paste(im, (4 + k * (cw + 4), 8 + r * (ch + 8)))
            board.save(rdir / "2_blur.jpg", quality=85)
        else:
            (rdir / "2_blur.jpg").unlink(missing_ok=True)

        # 3) 커버 | 3:4 그리드 미리보기 (가운데 기준으로 위아래 잘림)
        if cover.exists():
            c = Image.open(cover).convert("RGB").resize((540, 960))
            g = c.crop((0, (960 - 720) // 2, 540, (960 + 720) // 2))
            board = Image.new("RGB", (540 * 2 + 24, 960 + 50), (40, 40, 40))
            board.paste(c, (8, 42))
            board.paste(g, (540 + 16, 42 + 120))
            d = ImageDraw.Draw(board)
            d.text((10, 4), "커버 원본", font=fnt, fill="white")
            d.text((540 + 18, 4), "프로필 그리드(3:4)", font=fnt, fill="white")
            board.save(rdir / "3_cover.jpg", quality=85)

    # ── 보고서 ──
    nfail = sum(r[1] == FAIL for r in rows)
    nwarn = sum(r[1] == WARN for r in rows)
    out = [f"# 자동 검수: {title}", "",
           f"결과: ❌ {nfail}개 · ⚠️ {nwarn}개 · 👀 눈 확인 {sum(r[1] == LOOK for r in rows)}개", "",
           "| 구분 | 결과 | 항목 | 내용 |", "|---|---|---|---|"]
    out += [f"| {a} | {b} | {c} | {d} |" for a, b, c, d in rows]
    out += ["", "확인 이미지: " + ", ".join(S.rel(p) for p in sorted(rdir.glob("*.jpg")))]
    text = "\n".join(out) + "\n"
    (rdir / "report.md").write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
