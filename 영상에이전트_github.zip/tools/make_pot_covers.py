from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(r"[가림]")
FONT_EBOLD = str(ROOT / "tools" / "fonts" / "Pretendard-ExtraBold.otf")
W, H = 1080, 1920

def create_gradient_mask(w, h, start_y=950, max_alpha=220):
    gradient = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(gradient)
    for y in range(start_y, h):
        progress = (y - start_y) / (h - start_y)
        alpha = int((progress ** 1.3) * max_alpha)
        draw.line([(0, y), (w, y)], fill=(0, 0, 0, alpha))
    return gradient

def add_thumbnail_text(base_img, lines, font_size=62, x=75, bottom_y=1420):
    img = base_img.convert("RGBA")
    grad = create_gradient_mask(W, H, start_y=950, max_alpha=220)
    img = Image.alpha_composite(img, grad)

    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_EBOLD, font_size)

    line_height = int(font_size * 1.32)
    total_text_h = len(lines) * line_height
    start_y = bottom_y - total_text_h

    for i, line in enumerate(lines):
        y = start_y + i * line_height
        for dx, dy, s_alpha in [(-2, 2, 90), (2, 2, 130), (0, 3, 110)]:
            draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0, s_alpha))
        draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))

    return img.convert("RGB")

out_dir = ROOT / "output" / "군고구마" / "캡컷용"

# Option A: Inside Pot with Glowing Charcoal & Sweet Potato circle (Extremely unique visual)
img_inside = Image.open(ROOT / "work" / "pot_inside_01.jpg")
t_a1 = add_thumbnail_text(img_inside, ["항아리 숯불에 구운", "인생 호박고구마"])
t_a1.save(out_dir / "항아리내부_1안_인생호박고구마.jpg", quality=95)
t_a1.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_항아리내부_1안.jpg", quality=95)

t_a2 = add_thumbnail_text(img_inside, ["유튜브 330만 터진", "미사 항아리 군고구마"])
t_a2.save(out_dir / "항아리내부_2안_유튜브330만.jpg", quality=95)
t_a2.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_항아리내부_2안.jpg", quality=95)

# Option B: Master at the Pot with '군고구마' Golden Letters (Documentary feel, just like 족발집/달인 reference)
img_master = Image.open(ROOT / "work" / "pot_master_06.jpg")
t_b1 = add_thumbnail_text(img_master, ["항아리 숯불에 구운", "인생 호박고구마"])
t_b1.save(out_dir / "항아리장인_1안_인생호박고구마.jpg", quality=95)
t_b1.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_항아리장인_1안.jpg", quality=95)

t_b2 = add_thumbnail_text(img_master, ["유튜브 330만 터진", "미사 항아리 군고구마"])
t_b2.save(out_dir / "항아리장인_2안_유튜브330만.jpg", quality=95)
t_b2.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_항아리장인_2안.jpg", quality=95)

# Update main covers to 항아리 2안
t_a2.save(ROOT / "output" / "군고구마" / "군고구마_cover.jpg", quality=95)
t_a2.save(ROOT / "output" / "군고구마" / "군고구마_나레이션_cover.jpg", quality=95)

print("Created 항아리 thumbnails successfully!")
