import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(r"[가림]")
FONT_EBOLD = str(ROOT / "tools" / "fonts" / "Pretendard-ExtraBold.otf")
FFMPEG = str(ROOT / "tools" / "ffmpeg" / "bin" / "ffmpeg.exe")

W, H = 1080, 1920

def create_gradient_mask(w, h, start_y=900, max_alpha=210):
    gradient = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(gradient)
    for y in range(start_y, h):
        progress = (y - start_y) / (h - start_y)
        alpha = int((progress ** 1.3) * max_alpha)
        draw.line([(0, y), (w, y)], fill=(0, 0, 0, alpha))
    return gradient

def add_thumbnail_text(base_img, lines, font_size=62, x=75, bottom_y=1420):
    img = base_img.convert("RGBA")
    grad = create_gradient_mask(W, H, start_y=950, max_alpha=215)
    img = Image.alpha_composite(img, grad)

    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_EBOLD, font_size)

    line_height = int(font_size * 1.32)
    total_text_h = len(lines) * line_height
    start_y = bottom_y - total_text_h

    for i, line in enumerate(lines):
        y = start_y + i * line_height
        # Draw soft shadow
        for dx, dy, s_alpha in [(-2, 2, 90), (2, 2, 130), (0, 3, 110)]:
            draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0, s_alpha))
        # Draw main text in pure white
        draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))

    return img.convert("RGB")

def extract_frame(video_path, time_sec):
    out_path = ROOT / "work" / f"frame_potato_{time_sec}.jpg"
    cmd = [
        FFMPEG, "-y",
        "-ss", str(time_sec),
        "-i", str(video_path),
        "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
        "-frames:v", "1",
        "-q:v", "2",
        str(out_path)
    ]
    subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return Image.open(out_path)

def make_sweetpotato_covers():
    # Frame from 20261124_131830.mp4 at 6.0s (hands breaking open the golden sweet potato)
    frame = extract_frame(ROOT / "input" / "군고구마" / "20261124_131830.mp4", 6.0)

    out_dir = ROOT / "output" / "군고구마" / "캡컷용"
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1안: 항아리 숯불에 구운 / 인생 호박고구마
    opt1 = add_thumbnail_text(frame, ["항아리 숯불에 구운", "인생 호박고구마"])
    opt1.save(out_dir / "썸네일_1안_인생호박고구마.jpg", quality=95)
    opt1.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_1안_정사각형미리보기.jpg", quality=95)

    # 2안: 유튜브 330만 터진 / 미사 항아리 군고구마
    opt2 = add_thumbnail_text(frame, ["유튜브 330만 터진", "미사 항아리 군고구마"])
    opt2.save(out_dir / "썸네일_2안_유튜브330만.jpg", quality=95)
    opt2.crop((0, 420, 1080, 1500)).save(out_dir / "인스타그리드_2안_정사각형미리보기.jpg", quality=95)

    print("Generated 1안 and 2안 covers successfully!")

if __name__ == "__main__":
    make_sweetpotato_covers()
